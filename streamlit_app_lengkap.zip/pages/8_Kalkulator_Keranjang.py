import streamlit as st
import pandas as pd
from utils.pipeline import load_data
from utils.styling import apply_custom_theme, render_brand_header

st.set_page_config(page_title="Kalkulator Keranjang", layout="wide")
apply_custom_theme()
render_brand_header()

st.title("Kalkulator Keranjang Belanja")
st.caption("Simulasikan isi keranjang customer, bisa lebih dari satu produk sekaligus. Sistem menyarankan produk tambahan berdasarkan seluruh rules yang cocok dengan isi keranjang.")

data = load_data()
rules = data["rules"]
daftar_produk = sorted(data["rfm"]["ITEM"].unique())

keranjang = st.multiselect("Isi keranjang (pilih satu atau lebih produk)", daftar_produk)

if keranjang:
    st.markdown('<hr class="header-garis">', unsafe_allow_html=True)
    st.write("Isi keranjang saat ini:", ", ".join(keranjang))

    saran = rules[
        rules["antecedents"].apply(lambda a: any(p in a for p in keranjang))
        & ~rules["consequents"].apply(lambda c: any(p in c for p in keranjang))
    ].copy()
    saran = saran.sort_values("lift", ascending=False)

    if saran.empty:
        st.warning("Belum ada saran produk tambahan berdasarkan rules resmi untuk kombinasi keranjang ini.")
    else:
        st.subheader(f"{len(saran)} saran produk tambahan")
        saran_disp = saran[["antecedents", "consequents", "confidence", "lift"]].rename(columns={
            "antecedents": "Karena keranjang cocok dengan",
            "consequents": "Disarankan tambah",
            "confidence": "Confidence", "lift": "Lift",
        }).head(15)
        st.dataframe(saran_disp, use_container_width=True, hide_index=True)

        top = saran.iloc[0]
        st.success(f"Saran terkuat: tambahkan {top['consequents']} ke keranjang (confidence {top['confidence']*100:.1f} persen, lift {top['lift']:.2f}).")

        subset = data["rfm"][data["rfm"]["ITEM"].isin(keranjang)]
        if subset["Frequency"].sum() > 0:
            estimasi_revenue = subset["Monetary"].sum() / subset["Frequency"].sum()
            st.caption(f"Rata-rata nilai transaksi historis untuk produk di keranjang ini: Rp {estimasi_revenue:,.0f}".replace(",", "."))
else:
    st.info("Pilih minimal satu produk di atas untuk mulai simulasi.")
